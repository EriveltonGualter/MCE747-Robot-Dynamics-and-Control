%Example - fmincon

A=[-1 -1];B=-1; %ineq. constr. matrices

x0=[1;-1];  %initial guess

[xopt,obj]=fmincon(@(x) myobj(x),x0, A,B,[],[]);

%Plot
[X1,X2]=meshgrid([-2:0.1:2]);
Z=X1.^2+2*X2.^2;

surf(X1,X2,Z)
view(-44,32)

figure(2)

[C,h]=contour(X1,X2,Z,[0 0.1 0.2 0.3 0.4 0.5 0.666 0.7 0.8]);
clabel(C,h)
hold on
x1=[-2:2];
x2=1-x1;
plot(x1,x2,'r','LineWidth',2)