function out=Transx(a)

out=[eye(3) [a;0;0];0 0 0 1];
