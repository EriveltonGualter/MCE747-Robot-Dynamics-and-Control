function [c,ceq]=qconstr(x)
%x is the search vector x=[q1a;q1b;qL]

q1a=x(1);
q1b=x(2);
qL=x(3);

l1=0.4;
l2=0.3;

%Problem 1: Endpoint must not be below ground level, can be far from 
%workpiece

ya0=l1*sin(q1a)-l2*cos(qL);
yb0=l1*sin(q1b)-l2*cos(qL);

c=-min(ya0,yb0);

ceq=[];