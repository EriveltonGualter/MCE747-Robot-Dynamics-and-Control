function L=lengthobj(x)

%x is the search vector x=[q1a;q1b;qL]

q1a=x(1);
q1b=x(2);
qL=x(3);

%Minimize the negative of the length

L=-abs(cos(q1b-qL)-cos(q1a-qL));
