%Optimizations for drilling example

%Symbolic processing for various necessary formulas:

syms q1a q1b qL l1 l2 h

%coordinates of endpoint restricted to desired orientation:
%Use q1+q2=qL-pi/2
%See notes

xa0=l1*cos(q1a)+l2*sin(qL); 
ya0=l1*sin(q1a)-l2*cos(qL);  

xb0=l1*cos(q1b)+l2*sin(qL);
yb0=l1*sin(q1b)-l2*cos(qL);

H10=Rotz(qL-pi/2)*Transx(h);
H01=inv(H10);

%Transfer points to frame 1

Pa1=H01*[xa0;ya0;0;1];
Pb1=H01*[xb0;yb0;0;1];

ya1=simplify(Pa1(2)); %doesn't depend on h
yb1=simplify(Pb1(2));

x1=simplify(Pa1(1)); %this will be used for problem 2

%Find the length of projection

%L=l1*abs(cos(q1b-qL)-cos(q1a-qL))

%Problem 1:
%Maximize  L/l1 over qL, q1a, q1b subject to 

%q1a in [0,pi]
%q1b in [0,pi]
%ya0 >=0 
%yb0 >=0

%Use fmincon
x0=[0;pi/2;2*pi/3]; %initial guess
UB=[pi;pi;pi];LB=[0;0;0];
[x,Lopt]=fmincon(@(x) lengthobj(x),x0,[],[],[],[],LB,UB, @(x) qconstr(x));

%Rescale
l1=0.4;
L=abs(Lopt*l1);
%Number of holes:
d=0.02;
N=L/d


%Problem 2:
%Distance from endpoint to line (should be negative for all q1 in range but not
%smaller than -2 cm )
%d=l1*sin(q1+qL) - h - l2*cos(2*qL)

x0=[0;pi;pi;1]; %initial guess
UB=[pi;pi;pi;10];LB=[0;0;0;0];
[x,Lopt]=fmincon(@(x) lengthobj2(x),x0,[],[],[],[],LB,UB, @(x) qconstr2(x));
%Rescale
L=abs(Lopt*l1);
%Number of holes:
d=0.02;
N=L/d

%Trapped in local minimum. We know that
%x=[1.2661;pi-1.2661;pi;0.7] is more optimal (Lopt=-0.6, with N=12)


