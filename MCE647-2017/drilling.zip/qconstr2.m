function [c,ceq]=qconstr2(x)

%x is the search vector x=[q1a;q1b;qL;h]

q1a=x(1);
q1b=x(2);
qL=x(3);
h=x(4);

l1=0.4;
l2=0.3;


ya0=l1*sin(q1a)-l2*cos(qL);
yb0=l1*sin(q1b)-l2*cos(qL);


%Problem 2: Endpoint must not be below ground level, cannot be farther than
%2 cm from workpiece or interfere with it.

c1=-min(ya0,yb0);

%sort q1a and q1b
qa=min(q1a,q1b);qb=max(q1a,q1b);
del=(qb-qa)/100; %use 100 points between qa and qb
q=[qa:del:qb];

d=l2-h-l1*sin(q-qL); %This must be between 0 and -0.02 for each q in [q1a,q1b]


c2=max(d);
c3=-min(d)-0.02;

c=[c1;c2;c3];

ceq=[];