function MAINroboticsHW2(p)
    close all
    addpath('Homogeneous Primitive Transformation');
    switch p
        case 1
            problem2
        case 2
            problem3
        case 3
            problem3_part2
    end
end