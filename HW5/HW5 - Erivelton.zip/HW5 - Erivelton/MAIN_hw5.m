% Erivelton Gualter dos Santos
% MCE747 - Robot Dynamics and Control 
%
% Homework 5

close all
clear all
clc

% Simulation time, s
T = 5;
ts = 1e-3;

% Get Inertia, Coriolis and Gravitational matrix
if ~exist('Dfcn', 'var')
    [D, C, gq, Dfcn, Cfcn, Gfcn] = getTermWAM();
end

getRegressor3

% Initial Conditional
q10 = 0;
q20 = 0;
q40 = 0;
q1d0 = 0;
q2d0 = 0;
q4d0 = 0;

Q0 = [q10; q20; q40; q1d0; q2d0; q4d0];

disp('Simulating for Tau = sin(t) ...');
tauAmp = 1;
sim('sim_WAM', T);

disp('Plotting ...');
plotQ(t,Q); print('Simulation1', '-dpng');
clear t Q

disp('Simulating for Tau = 0 ...');
tauAmp = 0;
sim('sim_WAM', T);

disp('Plotting ...');
plotQ(t,Q); print('Simulation2', '-dpng');

disp(' ');
disp('For a ZERO initial condition (q, qdot), there is a nonzero initial acceleration.');
disp('-inv(Dfcn(0,0,0))*Gfcn(0,0,0)');
-inv(Dfcn(0,0,0))*Gfcn(0,0,0)

function plotQ(t,Q)
    figure('Name', 'States');
    subplot(311); hold on; box on; plot(t, Q(:,1), t, Q(:,2), t, Q(:,3), 'LineWidth', 2);   ylabel('q_i'); legend('Link 1','Link 2','Link 4');
    subplot(312); hold on; box on; plot(t, Q(:,4), t, Q(:,5), t, Q(:,6), 'LineWidth', 2);   ylabel('qdot_i')
    subplot(313); hold on; box on; plot(t, Q(:,10), t, Q(:,11), t, Q(:,12), 'LineWidth', 2);ylabel('qddot_i'); xlabel('Time, s')
end
