
load('symbolicvars.mat')

%% REgressor
disp('Geeting Regressor Parameters for D Matrix ...');

syms QJ;
syms TH1 TH2 TH3 TH4 TH5 TH6 TH7 TH8 TH9 TH10 TH11 TH12 TH13 TH14 TH15 TH16 TH17 TH18 TH19 TH20 TH21

THsym = [TH1 TH2 TH3 TH4 TH5 TH6 TH7 TH8 TH9 TH10 TH11 TH12 TH13 TH14 TH15 TH16 TH17 TH18 TH19 TH20 TH21];

% ---------------------------- Inertia Matrix -----------------------------
% -------------------------------------------------------------------------
D11 = expand(D(1,1), 'ArithmeticOnly', true);
k = 1;
THarr(k) = I1yy + I2xx/2 + I3xx/2 + I4xx/2 + I3yy/2 + I2zz/2 + I4zz/2 + (a^2*m3)/2 + ...
    a^2*m4 + (d^2*m3)/2 + (d^2*m4)/2 + m1*xc1^2 + (m2*xc2^2)/2 + (m3*xc3^2)/2 + ...
    (m4*xc4^2)/2 + m2*yc2^2 + (m3*yc3^2)/2 + m4*yc4^2 + m1*zc1^2 + (m2*zc2^2)/2 + ...
    m3*zc3^2 + (m4*zc4^2)/2 + a*m3*xc3 - a*m4*xc4 - d*m3*yc3;

Yarr = [1;
        cos(2*q2 + 2*q4);
        sin(2*q2 + 2*q4);
        cos(2*q2 + q4);
        sin(2*q2 + q4);
        cos(2*q2);
        sin(2*q2);
        cos(q4);
        sin(q4)
        ];
   
D11 = simplify(D11 - THarr(k)*Yarr(k));
for k=2:size(Yarr)
    term = subs(D11, Yarr(k), QJ);
    THarr(k) = diff(term,QJ);   
    D11 = simplify(D11 - THarr(k)*Yarr(k));
end
 
% -------------------------------------------------------------------------
D12 = simplify(D(1,2));

Yarr = [Yarr;
        cos(q2 + q4);
        sin(q2 + q4);
        cos(q2);
        sin(q2)
        ];

for k=10:size(Yarr)
    term = subs(D12, Yarr(k), QJ);
    THarr(k) = diff(term,QJ);   
    D12 = simplify(D12 - THarr(k)*Yarr(k));
end

% -------------------------------------------------------------------------
D13 = simplify(D(1,3));

Yarr = [Yarr;
        cos(q2 + q4);
        sin(q2 + q4)
        ];

for k=14:size(Yarr)
    term = subs(D13, Yarr(k), QJ);
    THarr(k) = diff(term,QJ);   
    D13 = simplify(D13 - THarr(k)*Yarr(k));
end
 
% -------------------------------------------------------------------------
D23 = simplify(D(2,3));

k = k+1;
THarr(k) = I4yy + a^2*m4 + m4*xc4^2 + m4*zc4^2 - 2*a*m4*xc4;

Yarr = [Yarr;
        1;
        cos(q4);
        sin(q4)
        ];

D23 = simplify(D23 - THarr(k)*Yarr(k));
for k=17:size(Yarr)
    term = subs(D23, Yarr(k), QJ);
    THarr(k) = diff(term,QJ);   
    D23 = simplify(D23 - THarr(k)*Yarr(k));
end

% -------------------------------------------------------------------------
D22 = simplify(D(2,2));

Yarr = [Yarr;
        1;
        cos(q4);
        sin(q4)
        ];

k = k +1;
THarr(k) = I2yy + I4yy + I3zz + a^2*m3 + 2*a^2*m4 + d^2*m3 + d^2*m4 + m2*xc2^2 + ...
    m3*xc3^2 + m4*xc4^2 + m3*yc3^2 + m2*zc2^2 + m4*zc4^2 + 2*a*m3*xc3 - 2*a*m4*xc4 - 2*d*m3*yc3;

D22 = simplify(D22 - THarr(k)*Yarr(k));

for k=20:size(Yarr)
    term = subs(D22, Yarr(k), QJ);
    THarr(k) = diff(term,QJ);   
    D22 = simplify(D22 - THarr(k)*Yarr(k));
end

% -------------------------------------------------------------------------
D33 = simplify(D(3,3));

Yarr = [Yarr; 1];

k = k + 1;
THarr(k) = m4*a^2 - 2*m4*a*xc4 + m4*xc4^2 + m4*zc4^2 + I4yy;

D33 = simplify(D33 - THarr(k)*Yarr(k));
% TH and Y: 22

disp('Geeting Regressor Parameters for G Matrix ...');
% ------------------------ Gravitational Matrix ---------------------------
% -------------------------------------------------------------------------

G2 = simplify(gq(2));

Yarr = [Yarr;
        cos(q2 + q4);
        sin(q2 + q4);
        cos(q2);
        sin(q2)
        ];

for k=23:size(Yarr)
    term = subs(G2, Yarr(k), QJ);
    THarr(k) = diff(term,QJ);   
    G2 = simplify(G2 - THarr(k)*Yarr(k));
end
% TH and Y: from 23 to 26

% -------------------------------------------------------------------------
G3 = simplify(gq(3));

Yarr = [
        Yarr;
        cos(q2 + q4);
        sin(q2 + q4)
        ];
    
for k=27:size(Yarr)
    term = subs(G3, Yarr(k), QJ);
    THarr(k) = diff(term,QJ);   
    G3 = simplify(G3 - THarr(k)*Yarr(k));
end
% TH and Y: from 27 to 28

% 
% TH(17)-TH(21)
% TH(18)-TH(22)

% ------------------------ Assenbly Regressor ---------------------------
% -------------------------------------------------------------------------
[thu,~,ithu] = unique(THarr, 'stable');
TH = THsym(ithu);
disp(['Number of TH: ', num2str(length(THarr))]);
disp(['Number of TH without repetitions: ', num2str(length(thu))]);
disp('Thetas: ');
disp(thu.')

% Since there are 20 paremeters: size(Y) = 2x20

% Check Inertia Matrix
D_rgs(1,1) = Yarr(1:9).'*THarr(1:9).';
D_rgs(1,2) = Yarr(10:13).'*THarr(10:13).';
D_rgs(1,3) = Yarr(14:15).'*THarr(14:15).';
D_rgs(2,3) = Yarr(16:18).'*THarr(16:18).';
D_rgs(2,2) = Yarr(19:21).'*THarr(19:21).';
D_rgs(3,3) = Yarr(22).'*THarr(22).';

D_rgs(2,1) = D_rgs(1,2);
D_rgs(3,1) = D_rgs(1,3);
D_rgs(3,2) = D_rgs(2,3);

disp('Evalutation if D matrix was assemblyed correctly: D(q) - D(TH) ');
simplify(D - D_rgs)

% Check Gravitational array
G_rgs(1,1) = sym(gq(1));
G_rgs(2,1) = Yarr(23:26).'*THarr(23:26).';
G_rgs(3,1) = Yarr(27:28).'*THarr(27:28).';

disp('Evalutation if D matrix was assemblyed correctly: qg(q) - qg(TH) ');
simplify(gq - G_rgs)

% Replace terms by Theta Parameters
D_rgs(1,1) = Yarr(1:9).'*TH(1:9).';
D_rgs(1,2) = Yarr(10:13).'*TH(10:13).';
D_rgs(1,3) = Yarr(14:15).'*TH(14:15).';
D_rgs(2,3) = Yarr(16:18).'*TH(16:18).';
D_rgs(2,2) = Yarr(19:21).'*TH(19:21).';
D_rgs(3,3) = Yarr(22).'*TH(22).';

D_rgs(2,1) = D_rgs(1,2);
D_rgs(3,1) = D_rgs(1,3);
D_rgs(3,2) = D_rgs(2,3);

G_rgs(1,1) = sym(gq(1));
G_rgs(2,1) = Yarr(23:26).'*TH(23:26).';
G_rgs(3,1) = Yarr(27:28).'*TH(27:28).';

% Coriolis/Centripetal Matrix
for i=1:3
    for j=1:3
        for k=1:3
            c(i,j,k) = .5* ( diff(D_rgs(k,j),q(i)) + diff(D_rgs(k,i),q(j)) - diff(D_rgs(i,j),q(k)));
        end
    end
end

for k=1:3
    for j=1:3
        C_rgs(k,j) = c(1,j,k)*q1dot + c(2,j,k)*q2dot + c(3,j,k)*q4dot;
    end
end

disp('Geeting aux = D(q)qddot + C(q,qdot)qdot + g(q) from parameterization ...');
aux = D_rgs*qddot + C_rgs*qdot + G_rgs;  % From parameterization

disp('Assembly Y matrix ...');
for i=1:3                                   % Number of rows (links)
    for j=1:length(THsym)                   % Number of parameters
        Y(i,j)=diff(aux(i),THsym(j));
    end
end

disp('Geeting aux1 = Y*TH ...');
aux1 = Y*THsym.';

disp('Then Aux - Aux1 = ');
simplify(aux-aux1)

