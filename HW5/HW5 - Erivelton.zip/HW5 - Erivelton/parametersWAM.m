%Kinematics and parameters for the WAM 4 DOF robot
%Third joint will be frozen at q3 = 0

%Frames and kinematics:
%see https://support.barrett.com/wiki/WAM/KinematicsJointRangesConversionFactors

cm11 = [-0.00443422;0.12189039;-0.00066489;1];
cm22 = [-0.00236983;0.03105614;0.01542114;1];
cm33 = [-0.03825858;0.20750770;0.00003309;1];
cm44 = [0.01095471;-0.00002567;0.14053900;1];

%gravity
g = 9.81;

%Local CM coordinates
xc1 = -0.00443422;
yc1 = 0.12189039;
zc1 = -0.00066489;
xc2 = -0.00236983;
yc2 = 0.03105614;
zc2 = 0.01542114;
xc3 = -0.03825858;
yc3 = 0.20750770;
zc3 = 0.00003309;
xc4 = 0.01095471;
yc4 = -0.00002567;
zc4 = 0.14053900;

%Moments of inertia
I1xx = 0.29486350;
I1xy = -0.00795023;
I1xz = -0.00009311;
I1yy = 0.11350017;
I1yz = -0.00018711;
I1zz = 0.25065343;

I2xx = 0.02606840;
I2xy = -0.00001346;
I2xz = -0.00011701;
I2yy = 0.01472202;
I2yz = 0.00003659;
I2zz = 0.01934814;

I3xx = 0.13671601;
I3xy = -0.01680434;
I3xz = 0.00000510;
I3yy = 0.00588354;
I3yz = -0.00000530;
I3zz = 0.13951371;

I4xx = 0.03952350;
I4xy = 0.00000189;
I4xz = 0.00003117;
I4yy = 0.04008214;
I4yz = 0.00000131;
I4zz = 0.00210299;

%Link masses
m1 = 10.76768767;
m2 = 3.87493756;
m3 = 1.80228141;
m4 = 1.06513649; %elbow+blank link

%Other kinematic parameters
a = 0.045;
d = 0.35;
