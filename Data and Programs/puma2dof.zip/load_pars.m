%load_pars.m

global I1y I2x I2y I2z d2 m2 d3 I2x g

I1y=1;
I2y=2;
I2z=3;
d2=3;
m2=4;
d3=2;
I2x=3;
g=9.81;

